"use client";

import { motion } from "motion/react";
import ReviewCard from "@/components/ReviewCard";
import { Star } from "lucide-react";

const reviews = [
  {
    name: "Sarah Jenkins",
    rating: 5,
    text: "Absolutely amazing service! They fixed my iPhone 13 Pro Max screen in under an hour. Highly recommend!",
    imageUrl: "https://picsum.photos/seed/sarah/100/100",
  },
  {
    name: "Michael Chen",
    rating: 5,
    text: "Very professional and affordable. My battery was dying by noon, now it lasts all day. Thank you Just New One!",
    imageUrl: "https://picsum.photos/seed/michael/100/100",
  },
  {
    name: "Emily Rodriguez",
    rating: 4,
    text: "Great experience. The staff was friendly and explained exactly what was wrong with my charging port.",
    imageUrl: "https://picsum.photos/seed/emily/100/100",
  },
  {
    name: "David Smith",
    rating: 5,
    text: "I thought my water-damaged phone was dead forever. They managed to recover all my photos and get it working again. Lifesavers!",
    imageUrl: "https://picsum.photos/seed/david/100/100",
  },
  {
    name: "Jessica Lee",
    rating: 5,
    text: "Fastest repair I've ever had. Walked in, got a coffee next door, and my iPad screen was fixed when I got back.",
    imageUrl: "https://picsum.photos/seed/jessica/100/100",
  },
  {
    name: "Robert Johnson",
    rating: 4,
    text: "Good prices and honest technicians. They didn't try to upsell me on things I didn't need.",
    imageUrl: "https://picsum.photos/seed/robert/100/100",
  },
];

export default function ReviewsPage() {
  return (
    <div className="pt-32 pb-24 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold text-slate-900 mb-6"
          >
            Customer Reviews
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg text-slate-600 mb-8"
          >
            See what our customers have to say about our repair services. We
            pride ourselves on delivering excellent results and customer
            satisfaction.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex items-center justify-center gap-4 bg-white p-6 rounded-3xl shadow-sm border border-slate-100 max-w-sm mx-auto"
          >
            <div className="text-4xl font-bold text-slate-900">4.9</div>
            <div>
              <div className="flex items-center gap-1 mb-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 text-yellow-400 fill-yellow-400"
                  />
                ))}
              </div>
              <div className="text-sm text-slate-500 font-medium">
                Based on 500+ reviews
              </div>
            </div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {reviews.map((review, index) => (
            <ReviewCard key={index} {...review} delay={index * 0.1} />
          ))}
        </div>
      </div>
    </div>
  );
}
