"use client";

import { motion } from "motion/react";
import {
  Smartphone,
  Battery,
  Zap,
  Camera,
  Droplets,
  ShieldCheck,
  Speaker,
  Wifi,
  Cpu,
} from "lucide-react";
import ServiceCard from "@/components/ServiceCard";

const allServices = [
  {
    title: "Screen Replacement",
    description:
      "Fast and reliable screen replacement using high-quality OEM parts. Get your display looking brand new.",
    icon: Smartphone,
  },
  {
    title: "Battery Replacement",
    description:
      "Is your phone dying too quickly? We replace old batteries with new, high-capacity ones.",
    icon: Battery,
  },
  {
    title: "Charging Port Repair",
    description:
      "Having trouble charging? We clean, repair, or replace faulty charging ports.",
    icon: Zap,
  },
  {
    title: "Camera Repair",
    description:
      "Blurry photos or broken lens? We fix front and rear cameras for crystal clear shots.",
    icon: Camera,
  },
  {
    title: "Back Glass Replacement",
    description:
      "Cracked back glass? We use laser technology for precise and safe back glass removal.",
    icon: ShieldCheck,
  },
  {
    title: "Water Damage Repair",
    description:
      "Dropped your phone in water? Bring it to us immediately for professional liquid damage recovery.",
    icon: Droplets,
  },
  {
    title: "Speaker & Mic Repair",
    description:
      "Can't hear calls or play music? We fix earpieces, loudspeakers, and microphones.",
    icon: Speaker,
  },
  {
    title: "Antenna & Wifi Repair",
    description:
      "Weak signal or no Wifi? We diagnose and repair connectivity issues.",
    icon: Wifi,
  },
  {
    title: "Motherboard Repair",
    description:
      "Complex logic board issues? Our micro-soldering experts can fix it.",
    icon: Cpu,
  },
];

export default function ServicesPage() {
  return (
    <div className="pt-32 pb-24 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold text-slate-900 mb-6"
          >
            Our Repair Services
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg text-slate-600"
          >
            From cracked screens to complex motherboard repairs, our certified
            technicians have the skills and tools to fix your device quickly and
            professionally.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {allServices.map((service, index) => (
            <ServiceCard key={index} {...service} delay={index * 0.1} />
          ))}
        </div>
      </div>
    </div>
  );
}
