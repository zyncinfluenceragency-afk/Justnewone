"use client";

import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { useRouter } from "next/navigation";
import {
  Users,
  Calendar,
  Star,
  Trash2,
  CheckCircle,
  XCircle,
  LogOut,
  Loader2,
} from "lucide-react";

interface Booking {
  id: string;
  name: string;
  phone: string;
  deviceModel: string;
  issueType: string;
  date: string;
  time: string;
  notes: string;
  status: "pending" | "completed";
}

interface Review {
  id: string;
  name: string;
  rating: number;
  text: string;
  status: "pending" | "approved";
}

export default function AdminDashboardPage() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    // Check auth
    const checkAuth = async () => {
      try {
        const res = await fetch("/api/auth/check");
        if (!res.ok) {
          router.push("/admin-login");
          return;
        }
        fetchData();
      } catch (err) {
        router.push("/admin-login");
      }
    };
    checkAuth();
  }, [router]);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [bookingsRes, reviewsRes] = await Promise.all([
        fetch("/api/bookings"),
        fetch("/api/reviews"),
      ]);

      if (bookingsRes.ok) setBookings(await bookingsRes.json());
      if (reviewsRes.ok) setReviews(await reviewsRes.json());
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/admin-login");
  };

  const deleteBooking = async (id: string) => {
    if (!confirm("Are you sure you want to delete this booking?")) return;
    try {
      await fetch(`/api/bookings/${id}`, { method: "DELETE" });
      setBookings(bookings.filter((b) => b.id !== id));
    } catch (err) {
      console.error("Error deleting booking:", err);
    }
  };

  const approveReview = async (id: string) => {
    try {
      await fetch(`/api/reviews/${id}/approve`, { method: "POST" });
      setReviews(
        reviews.map((r) => (r.id === id ? { ...r, status: "approved" } : r)),
      );
    } catch (err) {
      console.error("Error approving review:", err);
    }
  };

  const deleteReview = async (id: string) => {
    if (!confirm("Are you sure you want to delete this review?")) return;
    try {
      await fetch(`/api/reviews/${id}`, { method: "DELETE" });
      setReviews(reviews.filter((r) => r.id !== id));
    } catch (err) {
      console.error("Error deleting review:", err);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
      </div>
    );
  }

  const pendingBookings = bookings.filter((b) => b.status === "pending").length;
  const totalBookings = bookings.length;
  const totalReviews = reviews.length;

  return (
    <div className="min-h-screen bg-slate-50 pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">
              Admin Dashboard
            </h1>
            <p className="text-slate-500">
              Manage your bookings and customer reviews
            </p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-colors shadow-sm"
          >
            <LogOut className="w-4 h-4" /> Logout
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-4"
          >
            <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center shrink-0">
              <Calendar className="w-7 h-7" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500">
                Total Bookings
              </p>
              <p className="text-3xl font-bold text-slate-900">
                {totalBookings}
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-4"
          >
            <div className="w-14 h-14 bg-orange-50 text-orange-600 rounded-2xl flex items-center justify-center shrink-0">
              <Users className="w-7 h-7" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500">
                Pending Bookings
              </p>
              <p className="text-3xl font-bold text-slate-900">
                {pendingBookings}
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-4"
          >
            <div className="w-14 h-14 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center shrink-0">
              <Star className="w-7 h-7" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500">
                Total Reviews
              </p>
              <p className="text-3xl font-bold text-slate-900">
                {totalReviews}
              </p>
            </div>
          </motion.div>
        </div>

        {/* Content Grids */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Bookings */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100"
          >
            <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" /> Recent Bookings
            </h2>

            {bookings.length === 0 ? (
              <p className="text-slate-500 text-center py-8">
                No bookings found.
              </p>
            ) : (
              <div className="space-y-4">
                {bookings.map((booking) => (
                  <div
                    key={booking.id}
                    className="p-4 rounded-2xl border border-slate-100 bg-slate-50 hover:bg-white transition-colors"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-bold text-slate-900">
                        {booking.name}
                      </h3>
                      <span
                        className={`text-xs font-medium px-2.5 py-1 rounded-full ${booking.status === "pending" ? "bg-orange-100 text-orange-700" : "bg-green-100 text-green-700"}`}
                      >
                        {booking.status}
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-sm text-slate-600 mb-4">
                      <p>
                        <span className="font-medium">Phone:</span>{" "}
                        {booking.phone}
                      </p>
                      <p>
                        <span className="font-medium">Device:</span>{" "}
                        {booking.deviceModel}
                      </p>
                      <p>
                        <span className="font-medium">Issue:</span>{" "}
                        {booking.issueType}
                      </p>
                      <p>
                        <span className="font-medium">Date:</span>{" "}
                        {booking.date} {booking.time}
                      </p>
                    </div>
                    {booking.notes && (
                      <p className="text-sm text-slate-500 mb-4 italic">
                        &quot;{booking.notes}&quot;
                      </p>
                    )}
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => deleteBooking(booking.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete Booking"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>

          {/* Reviews */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100"
          >
            <h2 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Star className="w-5 h-5 text-green-600" /> Manage Reviews
            </h2>

            {reviews.length === 0 ? (
              <p className="text-slate-500 text-center py-8">
                No reviews found.
              </p>
            ) : (
              <div className="space-y-4">
                {reviews.map((review) => (
                  <div
                    key={review.id}
                    className="p-4 rounded-2xl border border-slate-100 bg-slate-50 hover:bg-white transition-colors"
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-bold text-slate-900">
                          {review.name}
                        </h3>
                        <div className="flex items-center gap-1 mt-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${i < review.rating ? "text-yellow-400 fill-yellow-400" : "text-slate-200 fill-slate-200"}`}
                            />
                          ))}
                        </div>
                      </div>
                      <span
                        className={`text-xs font-medium px-2.5 py-1 rounded-full ${review.status === "pending" ? "bg-orange-100 text-orange-700" : "bg-green-100 text-green-700"}`}
                      >
                        {review.status}
                      </span>
                    </div>
                    <p className="text-sm text-slate-600 mb-4 italic">
                      &quot;{review.text}&quot;
                    </p>
                    <div className="flex justify-end gap-2">
                      {review.status === "pending" && (
                        <button
                          onClick={() => approveReview(review.id)}
                          className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors"
                          title="Approve Review"
                        >
                          <CheckCircle className="w-4 h-4" />
                        </button>
                      )}
                      <button
                        onClick={() => deleteReview(review.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="Delete Review"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}
