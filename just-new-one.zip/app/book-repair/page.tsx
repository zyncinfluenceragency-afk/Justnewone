"use client";

import { motion } from "motion/react";
import BookingForm from "@/components/BookingForm";
import { MapPin, Phone, Clock, ShieldCheck } from "lucide-react";

export default function BookRepairPage() {
  return (
    <div className="pt-32 pb-24 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Info Section */}
          <div className="lg:col-span-5 space-y-8">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="mb-8"
            >
              <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
                Book Your Repair
              </h1>
              <p className="text-lg text-slate-600 leading-relaxed">
                Schedule an appointment to get your device fixed quickly. Most
                repairs are completed within an hour while you wait.
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 space-y-6"
            >
              <h3 className="text-xl font-bold text-slate-900 mb-4">
                Why Book Online?
              </h3>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-blue-50 rounded-full flex items-center justify-center shrink-0 text-blue-600">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-slate-900">
                    Skip the Line
                  </h4>
                  <p className="text-sm text-slate-600">
                    Priority service for booked appointments.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-green-50 rounded-full flex items-center justify-center shrink-0 text-green-600">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-slate-900">
                    Free Diagnostics
                  </h4>
                  <p className="text-sm text-slate-600">
                    We&apos;ll check your device for free before any repair.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-purple-50 rounded-full flex items-center justify-center shrink-0 text-purple-600">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-semibold text-slate-900">
                    Convenient Location
                  </h4>
                  <p className="text-sm text-slate-600">
                    Easy to find with ample parking available.
                  </p>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-slate-900 text-white p-8 rounded-3xl shadow-lg"
            >
              <h3 className="text-xl font-bold mb-4">Need immediate help?</h3>
              <p className="text-slate-300 mb-6">
                Our technicians are ready to assist you right now.
              </p>
              <a
                href="tel:01143590937"
                className="flex items-center justify-center gap-2 bg-white text-slate-900 px-6 py-3 rounded-full font-semibold hover:bg-slate-100 transition-colors"
              >
                <Phone className="w-5 h-5" /> Call 01143590937
              </a>
            </motion.div>
          </div>

          {/* Form Section */}
          <div className="lg:col-span-7">
            <BookingForm />
          </div>
        </div>
      </div>
    </div>
  );
}
