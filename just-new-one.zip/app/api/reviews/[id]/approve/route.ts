import { NextResponse } from "next/server";
import { store } from "@/lib/store";
import { cookies } from "next/headers";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const cookieStore = await cookies();
  const token = cookieStore.get("admin_token");

  if (!token || token.value !== "authenticated") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { id } = await params;
  const review = store.reviews.find((r) => r.id === id);

  if (review) {
    review.status = "approved";
    return NextResponse.json({ success: true, review });
  }

  return NextResponse.json({ error: "Not found" }, { status: 404 });
}
