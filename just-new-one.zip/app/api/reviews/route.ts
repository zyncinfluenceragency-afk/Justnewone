import { NextResponse } from "next/server";
import { store, Review } from "@/lib/store";
import { cookies } from "next/headers";

export async function GET() {
  const cookieStore = await cookies();
  const token = cookieStore.get("admin_token");

  if (!token || token.value !== "authenticated") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  return NextResponse.json(store.reviews);
}

export async function POST(request: Request) {
  try {
    const data = await request.json();

    const newReview: Review = {
      id: Math.random().toString(36).substring(2, 9),
      name: data.name,
      rating: data.rating,
      text: data.text,
      status: "pending",
      createdAt: new Date().toISOString(),
    };

    store.reviews.push(newReview);
    return NextResponse.json(newReview, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 },
    );
  }
}
