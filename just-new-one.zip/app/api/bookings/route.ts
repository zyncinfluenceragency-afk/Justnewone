import { NextResponse } from "next/server";
import { store, Booking } from "@/lib/store";
import { cookies } from "next/headers";

export async function GET() {
  const cookieStore = await cookies();
  const token = cookieStore.get("admin_token");

  if (!token || token.value !== "authenticated") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  return NextResponse.json(store.bookings);
}

export async function POST(request: Request) {
  try {
    const data = await request.json();

    const newBooking: Booking = {
      id: Math.random().toString(36).substring(2, 9),
      name: data.name,
      phone: data.phone,
      deviceModel: data.deviceModel,
      issueType: data.issueType,
      date: data.date,
      time: data.time,
      notes: data.notes || "",
      status: "pending",
      createdAt: new Date().toISOString(),
    };

    store.bookings.push(newBooking);
    return NextResponse.json(newBooking, { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 },
    );
  }
}
