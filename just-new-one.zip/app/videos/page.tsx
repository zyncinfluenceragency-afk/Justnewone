"use client";

import { motion } from "motion/react";
import VideoCard from "@/components/VideoCard";
import { PlayCircle } from "lucide-react";

const videos = [
  {
    title: "iPhone Repair Short 1",
    videoId: "v2BNzU4HwBU",
    thumbnailUrl: "https://img.youtube.com/vi/v2BNzU4HwBU/maxresdefault.jpg",
  },
  {
    title: "iPhone Repair Short 2",
    videoId: "SxSExE8WeU0",
    thumbnailUrl: "https://img.youtube.com/vi/SxSExE8WeU0/maxresdefault.jpg",
  },
  {
    title: "iPhone Repair Short 3",
    videoId: "SxSExE8WeU0",
    thumbnailUrl: "https://img.youtube.com/vi/SxSExE8WeU0/maxresdefault.jpg",
  },
  {
    title: "iPhone Repair Short 4",
    videoId: "wBketOXRA3c",
    thumbnailUrl: "https://img.youtube.com/vi/wBketOXRA3c/maxresdefault.jpg",
  },
  {
    title: "iPhone Repair Short 5",
    videoId: "JV5c5maihUU",
    thumbnailUrl: "https://img.youtube.com/vi/JV5c5maihUU/maxresdefault.jpg",
  },
];

export default function VideosPage() {
  return (
    <div className="pt-32 pb-24 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-5xl font-bold text-slate-900 mb-6"
          >
            Repair Videos & Guides
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-lg text-slate-600 mb-8"
          >
            Watch our expert technicians perform complex repairs, teardowns, and
            share tips on maintaining your devices.
          </motion.p>
          <motion.a
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            href="https://youtube.com/@justnewone1?si=JSXRz1dhiuxjmeGk"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-white bg-red-600 font-medium hover:bg-red-700 transition-colors px-6 py-3 rounded-full shadow-md hover:shadow-lg"
          >
            <PlayCircle className="w-5 h-5" /> Subscribe to our Channel
          </motion.a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {videos.map((video, index) => (
            <VideoCard key={index} {...video} delay={index * 0.1} />
          ))}
        </div>
      </div>
    </div>
  );
}
